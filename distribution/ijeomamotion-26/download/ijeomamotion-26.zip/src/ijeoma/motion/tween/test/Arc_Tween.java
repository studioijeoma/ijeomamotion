package ijeoma.motion.tween.test;

import ijeoma.motion.Motion;
import ijeoma.motion.tween.Tween;
import processing.core.PApplet;

public class Arc_Tween extends PApplet {
	int arcCount = 100;
	Arc[] arcs;

	float rx, ry, rz;
	Tween ryt;

	public void setup() {
		size(500, 500, P3D);
		smooth();

		Motion.setup(this);

		setupArcs();

		ryt = new Tween(400).add(this, "ry", TWO_PI).repeat().play();
	}

	public void setupArcs() {
		arcCount = 100;

		arcs = new Arc[arcCount];

		for (int i = 0; i < arcCount; i++)
			arcs[i] = new Arc(i * 400f / arcCount);
	}

	public void draw() {
		background(0);
		lights();
		smooth();

		pushMatrix();
		translate(width / 2, height / 2);
		rotateY(ry);
		rotateZ(TWO_PI - ry);
		for (Arc a : arcs)
			a.draw();
		popMatrix();
		
		String time = ryt.getTime() + " / " + ryt.getDuration();

		fill(255);
		text(time, width - textWidth(time) - 10, height - 10);
	}

	class Arc {
		float r;
		float b, e, p;
		int w, c;
		float rx, ry, rz;

		Tween rzt, pt;
		float rztd;

		Arc(float r) {
			this.r = r;
			c = color(random(255), random(255), random(255));
			w = (int) random(1, 10);
			rx = random(TWO_PI);
			ry = random(TWO_PI);

			rz = 0;
			rztd = random(75, 150);
			rzt = new Tween(rztd).add(this, "rz", TWO_PI).repeat().play();

			b = random(TWO_PI);
			e = b + random(PI / 6, PI / 2);

			p = b;
			pt = new Tween(100).add(this, "p", e).play();
		}

		void draw() {
			colorMode(HSB);
			strokeWeight(w);
			stroke(360 * rzt.getPosition(), 360, 360,
					360 - 360 * rzt.getPosition());
			noFill();
			pushMatrix();
			rotateX(rx);
			rotateY(ry);
			rotateZ(rz);
			arc(0, 0, r, r, b, p);
			popMatrix();
		}
	}

	public void keyPressed() {
		setupArcs();
	}

	public void mousePressed() {
		ryt.pause();
	}

	public void mouseReleased() {
		ryt.resume();
	}

	public void mouseDragged() {
		ryt.seek((float) mouseX / width);
	}
}
