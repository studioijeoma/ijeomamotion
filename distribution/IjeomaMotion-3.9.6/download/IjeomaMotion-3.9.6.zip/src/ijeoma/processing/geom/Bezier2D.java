/**
 * IjeomaMotion
 * Creates fast and easy time/frame based animations using tweens.
 * http://ekeneijeoma.com/processing/ijeomamotion
 *
 * Copyright (C) 2011 Ekene Ijeoma http://ekeneijeoma.com
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General
 * Public License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330,
 * Boston, MA  02111-1307  USA
 * 
 * @author      Ekene Ijeoma http://ekeneijeoma.com
 * @modified    11/14/2011
 * @version      (3.9.6)
 */
 
package ijeoma.processing.geom;

import processing.core.PApplet;
import processing.core.PVector;

public class Bezier2D {
	PApplet parent;
	float x1, y1, cx1, cy1, cx2, cy2, x2, y2;

	public Bezier2D(PApplet _parent, float _x1, float _y1, float _cx1, float _cy1, float _cx2, float _cy2, float _x2, float _y2) {
		parent = _parent;

		x1 = _x1;
		y1 = _y1;
		cx1 = _cx1;
		cy1 = _cy1;
		cx2 = _cx2;
		cy2 = _cy1;
		x2 = _x2;
		y2 = _y2;
	}

	public void draw() {
		parent.bezier(x1, y1, cx1, cy1, cx2, cy2, x2, y2);
	}

	public PVector getPoint(float _position) {
		float x = parent.bezierPoint(x1, cx1, cx2, x2, _position);
		float y = parent.bezierPoint(y1, cy1, cy2, y2, _position);

		return new PVector(x, y);
	}
}
