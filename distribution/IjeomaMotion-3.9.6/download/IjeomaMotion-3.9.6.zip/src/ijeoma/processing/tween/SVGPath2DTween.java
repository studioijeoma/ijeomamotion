/**
 * IjeomaMotion
 * Creates fast and easy time/frame based animations using tweens.
 * http://ekeneijeoma.com/processing/ijeomamotion
 *
 * Copyright (C) 2011 Ekene Ijeoma http://ekeneijeoma.com
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General
 * Public License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330,
 * Boston, MA  02111-1307  USA
 * 
 * @author      Ekene Ijeoma http://ekeneijeoma.com
 * @modified    11/14/2011
 * @version      (3.9.6)
 */

package ijeoma.processing.tween;

import java.lang.reflect.Method;

import ijeoma.motion.Motion;
import ijeoma.motion.event.MotionEvent;

import processing.core.PApplet;
import processing.core.PGraphics;
import processing.core.PShape;
import processing.core.PVector;

public class SVGPath2DTween extends Motion { // implements Comparable {
	private Method tweenSVGPathStartedMethod, tweenSVGPathEndedMethod,
			tweenSVGPathChangedMethod, tweenSVGPathRepeatedMethod;

	private PGraphics g;
	private PShape path;

	public SVGPath2DTween(String _name, PGraphics _g, PShape _path,
			float _begin, float _end, float _duration, float _delay,
			String _easing) {
		super(_name, _begin, _end, _duration, _delay, _easing);
		setupSVGPath(_g, _path);
	}

	public SVGPath2DTween(String _name, PGraphics _g, PShape _path,
			float _begin, float _end, float _duration, float _delay) {
		super(_name, _begin, _end, _duration, _delay);
		setupSVGPath(_g, _path);
	}

	public SVGPath2DTween(String _name, PGraphics _g, PShape _path,
			float _begin, float _end, float _duration) {
		super(_name, _begin, _end, _duration);
		setupSVGPath(_g, _path);
	}

	protected void setupSVGPath(PGraphics _g, PShape _path) {
		g = _g;
		path = _path;
	}

	/**
	 * Sets the events
	 */
	@Override
	protected void setupEvents() {
		Class<? extends PApplet> parentClass = parent.getClass();

		try {
			tweenSVGPathStartedMethod = parentClass.getMethod(
					MotionEvent.TWEEN_STARTED,
					new Class[] { SVGPath2DTween.class });
		} catch (Exception e) {
		}

		try {
			tweenSVGPathEndedMethod = parentClass.getMethod(
					MotionEvent.TWEEN_ENDED,
					new Class[] { SVGPath2DTween.class });
		} catch (Exception e) {
		}

		try {
			tweenSVGPathChangedMethod = parentClass.getMethod(
					MotionEvent.TWEEN_CHANGED,
					new Class[] { SVGPath2DTween.class });
		} catch (Exception e) {
		}

		try {
			tweenSVGPathRepeatedMethod = parentClass.getMethod(
					MotionEvent.TWEEN_REPEATED,
					new Class[] { SVGPath2DTween.class });
		} catch (Exception e) {
		}
	}

	public PVector getPoint() {
		PVector v = new PVector();

		return v;
	}

	public float getX() {
		return getPoint().x;
	}

	public float getY() {
		return getPoint().y;
	}

	public void setSVGPath(PShape _path) {
		path = _path;
	}

	public PShape getSVGPath() {
		return path;
	}

	@Override
	protected void dispatchMotionStartedEvent() {
		logger.println("dispatchMotionStartedEvent tweengroup");

		if (tweenSVGPathStartedMethod != null) {
			try {
				tweenSVGPathStartedMethod.invoke(parent, new Object[] { this });
			} catch (Exception e) {
				// e.printStackTrace();
				tweenSVGPathStartedMethod = null;
			}
		}

		dispatchEvent(MotionEvent.TWEEN_STARTED);
	}

	@Override
	protected void dispatchMotionEndedEvent() {
		if (tweenSVGPathEndedMethod != null) {
			try {
				tweenSVGPathEndedMethod.invoke(parent, new Object[] { this });
			} catch (Exception e) {
				e.printStackTrace();
				tweenSVGPathEndedMethod = null;
			}
		}

		dispatchEvent(MotionEvent.TWEEN_ENDED);
	}

	@Override
	protected void dispatchMotionChangedEvent() {
		if (tweenSVGPathChangedMethod != null) {
			try {
				tweenSVGPathChangedMethod.invoke(parent, new Object[] { this });
			} catch (Exception e) {
				// e.printStackTrace();
				tweenSVGPathChangedMethod = null;
			}
		}

		dispatchEvent(MotionEvent.TWEEN_CHANGED);
	}

	@Override
	protected void dispatchMotionRepeatedEvent() {
		if (tweenSVGPathRepeatedMethod != null) {
			try {
				tweenSVGPathRepeatedMethod
						.invoke(parent, new Object[] { this });
			} catch (Exception e) {
				// e.printStackTrace();
				tweenSVGPathRepeatedMethod = null;
			}
		}

		dispatchEvent(MotionEvent.TWEEN_REPEATED);
	}
}
