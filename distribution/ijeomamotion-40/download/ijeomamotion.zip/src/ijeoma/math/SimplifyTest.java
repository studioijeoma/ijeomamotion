package ijeoma.math;

public class SimplifyTest {

}
